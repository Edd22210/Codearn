import SwiftUI

struct AccountView: View {
 var userName: String
    var body: some View {
        Image(systemName: "person.circle.fill")
            .resizable()
            .frame(width:200,height:200)
            .offset(y:-250)
        Text("\(userName)")
            .font(.largeTitle)
            .offset(y:-250)
    }
}
