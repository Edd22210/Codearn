import SwiftUI

struct MenuView: View {
 var userName: String
    var body: some View {
        VStack {
            NavigationStack { 
                NavigationLink {
                    LanguageView()
                } label:{
                    ZStack {
                        RoundedRectangle(cornerRadius: 10)
                            .frame(width: 250, height: 50)
                            .foregroundStyle(.black)
                        Text("Coding Languages")
                            .foregroundStyle(.white)
                            .font(.title2)
                    }
                }
                NavigationLink {
                    AccountView(userName: userName)
                } label:{
                    ZStack {
                        RoundedRectangle(cornerRadius: 10)
                            .frame(width: 250, height: 50)
                            .foregroundStyle(.black)
                        Text("Account")
                            .foregroundStyle(.white)
                            .font(.title2)
                    }
                }
                NavigationLink {
                    SettingsView()
                } label:{
                    ZStack {
                        RoundedRectangle(cornerRadius: 10)
                            .frame(width: 250, height: 50)
                            .foregroundStyle(.black)
                        Text("Settings")
                            .foregroundStyle(.white)
                            .font(.title2)
                    }
                }
            }
        }
    }
}
