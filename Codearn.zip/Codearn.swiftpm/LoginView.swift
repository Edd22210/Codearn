import SwiftUI

struct LoginView: View {
    @State public var userName = String()
    @State var password = String()
    var body: some View {
        Text("Codearn")
            .font(.largeTitle)
            .bold()
            .padding()
        NavigationStack {
            TextField("Enter UserName", text: $userName)
                .textFieldStyle(.roundedBorder)
                .padding()
            SecureField("Enter UserName", text: $password)
                .textFieldStyle(.roundedBorder)
                .padding()
            NavigationLink {
                MenuView(userName: userName)
            } label:{
                ZStack {
                    RoundedRectangle(cornerRadius: 10)
                        .frame(width: 250, height: 50)
                        .foregroundStyle(.black)
                    Text("Login")
                        .foregroundStyle(.white)
                        .font(.title2)
                }
            }
        }
    }
}
