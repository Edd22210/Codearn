import SwiftUI

struct SettingsView: View {
    var body: some View {
        Text("Coming Soon")
            .font(.largeTitle)
            .bold()
    }
}
